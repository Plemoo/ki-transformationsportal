#!/usr/bin/env python3
from pathlib import Path
from html import escape
import json, shutil, zipfile, hashlib, os, sys

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "ai-business-strategy-whiteboard"
OUT.mkdir(exist_ok=True)
for stale in ("PDF-LIMITATION.txt", "AI-Business-Strategy-Transformation-Whiteboard.pdf", "MANIFEST.txt"):
    p = OUT / stale
    if p.exists(): p.unlink()

P = [
("P0","Orient","AI literacy, limits, responsible use.","Shared orientation and initial guardrails.","Explain opportunities and limits using a business example."),
("P1","Understand business / process","Map target outcome, process, friction, and baseline.","Business-problem and value-lever canvas.","Defend the problem without naming a tool or model."),
("P2","Select segment / discover","Form segment hypothesis; plan stakeholders, interviews, and evidence.","Segment and stakeholder profile plus evidence log.","Distinguish facts from market assumptions."),
("P3","Shape offer / portfolio","Define modular advisory offer, outcomes, exclusions, and commercial hypotheses.","Offer architecture.","Explain scope, value logic, and what is not promised."),
("P4","Design reversible pilot","Bound use case, baseline, success/stop criteria, and human oversight.","Pilot canvas and decision brief.","Pilot can fail safely and still inform a decision."),
("P5","Govern / enable change","Clarify roles, adoption, policy, and specialist reviews.","Governance and change plan.","Ownership and unresolved gates are visible."),
("P6","Prove value","Compare with baseline across business, process, people, quality, risk, and control effort.","Value evidence pack.","Recommend GO / ADAPT / HOLD / STOP without overstating evidence."),
("P7","Scale / operate","Define operating model, portfolio logic, monitoring, and continuous improvement.","Scale and operate blueprint.","Distinguish repeatability from production approval."),
]
T = [
("T0","Orientation & sponsorship","Shared ambition, sponsor, and initial boundaries."),
("T1","Current-state & process assessment","Baseline, pain points, and data/process readiness."),
("T2","Target picture & governance framing","Principles, decision rights, risk appetite, and ownership."),
("T3","Use-case portfolio decision","Compare value, feasibility, risk, dependency, and reversibility."),
("T4","Controlled pilot","Narrow scope; synthetic/minimal data where possible; human oversight and rollback."),
("T5","Gate decision & adoption","Specialist reviews, employee impact, training, and operating readiness."),
("T6","Value decision","Measured outcomes versus baseline, total effort, and unintended effects."),
("T7","Scale & operation","Portfolio governance, monitoring, incident/change process, and periodic revalidation."),
]
ENABLE = [
"P0 creates language for bounded T0 sponsorship.",
"P1 enables a credible T1 assessment.",
"P2 grounds T2 ownership in stakeholder evidence.",
"P3 makes T3 portfolio choices explicit.",
"P4 enables a bounded, reversible T4 pilot.",
"P5 makes T5 review and adoption gates visible.",
"P6 enables an evidence-based T6 decision.",
"P7 informs repeatable T7 operation—not approval.",
]
GATES = "GO · named next step only   |   ADAPT · change scope/method/artifact   |   HOLD · owner/evidence/review/prerequisite missing   |   STOP · not viable within acceptable limits"
COLORS = ["#2f6f67","#39776d","#477f72","#588879","#6f8c75","#8b8c6c","#a77c5f","#b36856"]

# Simple text wrapping for portable SVG text elements.
def wrap(text, limit):
    words=text.split(); lines=[]; cur=""
    for w in words:
        if len(cur)+len(w)+1<=limit: cur=(cur+" "+w).strip()
        else: lines.append(cur); cur=w
    if cur: lines.append(cur)
    return lines

def text_block(x,y,text, size=24, color="#19312e", weight=400, limit=38, line=1.25, anchor="start"):
    lines=wrap(text,limit)
    spans="".join(f'<tspan x="{x}" dy="{0 if i==0 else int(size*line)}">{escape(s)}</tspan>' for i,s in enumerate(lines))
    return f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}" font-weight="{weight}" text-anchor="{anchor}">{spans}</text>'

def card(x,y,w,h,code,title,focus,output,completion,color,kind="P"):
    body=[f'<g class="phase-card" data-phase="{code}" role="button" tabindex="0" aria-label="Open {code} {escape(title)} details">',
          f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="28" fill="#fffdf7" stroke="{color}" stroke-width="6"/>',
          f'<rect x="{x}" y="{y}" width="{w}" height="74" rx="28" fill="{color}"/><rect x="{x}" y="{y+48}" width="{w}" height="26" fill="{color}"/>',
          f'<text x="{x+24}" y="{y+49}" font-size="28" fill="white" font-weight="800">{code}</text>',
          f'<text x="{x+90}" y="{y+49}" font-size="25" fill="white" font-weight="700">{escape(title)}</text>',
          text_block(x+24,y+112,"FOCUS",18,color,800,40), text_block(x+24,y+143,focus,21,"#253a37",400,39,1.22)]
    cy=y+272
    if kind=="P":
        body += [text_block(x+24,cy,"OUTPUT",18,color,800,40),text_block(x+24,cy+31,output,21,"#253a37",400,39,1.22),
                 text_block(x+24,cy+126,"COMPLETION",18,color,800,40),text_block(x+24,cy+157,completion,21,"#253a37",400,39,1.22)]
    body += [f'<rect x="{x+24}" y="{y+h-55}" width="{w-48}" height="32" rx="16" fill="#eef1ea"/>',
             f'<text x="{x+w/2}" y="{y+h-33}" font-size="16" fill="#4a5b57" text-anchor="middle" font-weight="700">GO · ADAPT · HOLD · STOP</text>',
             '</g>']
    return "".join(body)

def panel(x,y,w,h,title,items,color="#2f6f67",size=22):
    s=[f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="28" fill="#fffdf7" stroke="#cad4cc" stroke-width="3"/>',
       f'<rect x="{x}" y="{y}" width="{w}" height="62" rx="28" fill="{color}"/><rect x="{x}" y="{y+36}" width="{w}" height="26" fill="{color}"/>',
       f'<text x="{x+26}" y="{y+42}" font-size="25" fill="white" font-weight="800">{escape(title)}</text>']
    yy=y+102
    for item in items:
        s.append(f'<circle cx="{x+31}" cy="{yy-7}" r="6" fill="{color}"/>')
        lines=wrap(item, int((w-75)/(size*.53)))
        s.append(text_block(x+52,yy,item,size,"#263c38",400,int((w-75)/(size*.53)),1.23))
        yy += max(55,len(lines)*int(size*1.23)+22)
    return "".join(s)

W,H=6200,3900
svg=[]
svg.append(f'''<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" role="img" aria-labelledby="title desc">
<title id="title">AI Business Strategy and Transformation Whiteboard</title><desc id="desc">An internal planning canvas connecting capability learning phases P0 to P7 with enterprise transformation stages T0 to T7, cross-cutting rails, decision gates, management evidence, and next decisions.</desc>
<defs><filter id="shadow" x="-10%" y="-10%" width="120%" height="130%"><feDropShadow dx="0" dy="10" stdDeviation="12" flood-color="#18322e" flood-opacity=".10"/></filter><marker id="arrow" markerWidth="12" markerHeight="12" refX="10" refY="6" orient="auto"><path d="M0 0L12 6L0 12z" fill="#71827c"/></marker><pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse"><path d="M40 0H0V40" fill="none" stroke="#dfe5df" stroke-width="1"/></pattern></defs>
<rect width="6200" height="3900" fill="#f3f0e7"/><rect width="6200" height="3900" fill="url(#grid)" opacity=".48"/>
<style>text{{font-family:Arial,Helvetica,sans-serif}} .phase-card{{cursor:pointer}} .phase-card:focus rect:first-of-type{{stroke:#d39a2c;stroke-width:12}} .phase-card:hover{{filter:url(#shadow)}} </style>''')
# top banner
svg += [f'<rect x="160" y="100" width="5880" height="190" rx="36" fill="#173d38" filter="url(#shadow)"/>',
        '<text x="230" y="166" font-size="28" fill="#bcd6c9" font-weight="800" letter-spacing="3">NORTH STAR · PLANNING TARGET — NOT A PROVEN OUTCOME</text>',
        '<text x="230" y="235" font-size="45" fill="#ffffff" font-weight="800">Introduce responsible AI to create measurable business value, improve selected processes,</text>',
        '<text x="230" y="278" font-size="45" fill="#ffffff" font-weight="800">enable people, and remain governable.</text>']
# context block
svg.append(panel(160,350,1320,400,"TRANSFORMATION QUESTION",[
"Which business problems should AI help solve?",
"For whom—customer, employee, or management?",
"Which process and decision are affected?",
"What evidence would justify GO, ADAPT, HOLD, or STOP?"],"#345e58",25))
# legend block
svg.append(panel(1520,350,3330,400,"DECISION GATE — APPLY AT EVERY PHASE",[
"GO — evidence supports only the named next step.",
"ADAPT — route remains valid; scope, method, or artifact changes.",
"HOLD — owner, evidence, specialist review, or prerequisite is missing.",
"STOP — problem, method, or route is not viable within acceptable limits."],"#7a633a",24))
svg.append(panel(4890,350,1150,400,"NAVIGATE & READ",[
"Big picture first; zoom for evidence detail.",
"HTML: wheel/pinch to zoom; drag to pan; click a phase to inspect.",
"Use phase selector or keyboard arrows; 0 resets the canvas."],"#44586f",22))
# Track headings
svg += ['<text x="160" y="850" font-size="34" fill="#173d38" font-weight="900">TRACK 1 · CAPABILITY &amp; ADVISORY LEARNING</text>',
        '<text x="160" y="1630" font-size="34" fill="#493c31" font-weight="900">TRACK 2 · ENTERPRISE AI TRANSFORMATION</text>']
# Cards positions
start=160; gap=24; cw=555; ph=620; th=470
for i,p in enumerate(P):
    x=start+i*(cw+gap)
    svg.append(card(x,890,cw,ph,*p,COLORS[i],"P"))
    if i<7: svg.append(f'<path d="M{x+cw+3} 1200H{x+cw+gap-6}" stroke="#71827c" stroke-width="7" marker-end="url(#arrow)"/>')
for i,t in enumerate(T):
    x=start+i*(cw+gap)
    svg.append(card(x,1670,cw,th,t[0],t[1],t[2],"","",COLORS[i],"T"))
    # connecting enabling relationship
    svg.append(f'<path d="M{x+cw/2} 1518V1650" stroke="{COLORS[i]}" stroke-width="5" stroke-dasharray="10 9" marker-end="url(#arrow)"/>')
    svg.append(f'<rect x="{x+35}" y="1530" width="{cw-70}" height="70" rx="18" fill="#f3f0e7" stroke="{COLORS[i]}" stroke-width="2"/>')
    svg.append(text_block(x+cw/2,1560,ENABLE[i],17,COLORS[i],700,45,1.16,"middle"))
    if i<7: svg.append(f'<path d="M{x+cw+3} 1905H{x+cw+gap-6}" stroke="#71827c" stroke-width="7" marker-end="url(#arrow)"/>')
# management panel right aligned unused x 4800+
svg.append(panel(4800,800,1240,1340,"MANAGEMENT CONTROL PANEL",[
"CURRENT EVIDENCE BASELINE — Strategy and sample artifacts may exist. Customer discovery, willingness to pay, a real baseline, value proof, technical feasibility, specialist approval, and scale readiness remain unproven unless evidenced.",
"RECOMMENDED NEXT DEPENDENCY — Deepen the earliest unresolved business-problem and value-lever evidence before advancing to attractive tools or scaling.",
"DECISION OWNERS — Executive sponsor; business process owner; AI/transformation lead; legal/privacy/security/labour specialists; finance/value owner; technology feasibility owner.",
"OPEN DECISIONS — Target segment; priority process; intended access/delivery; evidence source; pilot data class; named gate owners.",
"STATUS RULE — Reviews required; no approval assumed. Repeatability is not production readiness."],"#5a4b42",22))
# Rails
svg.append('<text x="160" y="2275" font-size="34" fill="#173d38" font-weight="900">CROSS-CUTTING RAILS · RUN THROUGH EVERY PHASE</text>')
rails=[
("1 · BUSINESS VALUE","Outcome → baseline → target hypothesis → measurement → decision.","#2f6f67"),
("2 · PEOPLE & CHANGE","Stakeholder impact → participation → capability → adoption → feedback.","#496b83"),
("3 · GOVERNANCE & SPECIALIST GATES","Legal · privacy · information security · labour law / works council · data rights · technical feasibility. REVIEWS REQUIRED; NO APPROVAL ASSUMED.","#9a623f"),
("4 · EVIDENCE & DECISION DISCIPLINE","Facts | assumptions & data gaps | options & trade-offs | risks & dependencies | recommendation & decision owner.","#745d7b")]
for i,(a,b,c) in enumerate(rails):
    y=2320+i*150
    svg += [f'<rect x="160" y="{y}" width="5880" height="116" rx="28" fill="#fffdf7" stroke="{c}" stroke-width="4"/>',
            f'<rect x="160" y="{y}" width="830" height="116" rx="28" fill="{c}"/><rect x="960" y="{y}" width="30" height="116" fill="{c}"/>',
            f'<text x="200" y="{y+70}" font-size="25" fill="white" font-weight="900">{escape(a)}</text>',
            text_block(1040,y+67,b,25,"#263c38",600,150,1.15)]
# Evidence zone
svg.append('<text x="160" y="3000" font-size="34" fill="#173d38" font-weight="900">EVIDENCE ZONE · COMPLETE BEFORE THE NEXT DECISION</text>')
evidence=[
("FACTS & SOURCES",["What is observed or documented?","Source, date, owner, and scope?","What contradicts it?"],"#2f6f67"),
("ASSUMPTIONS & DATA GAPS",["What are we treating as true?","Which gap could reverse the decision?","How will we test it?"],"#9a7b3f"),
("OPTIONS & TRADE-OFFS",["What are the credible alternatives?","Value, effort, reversibility, impact?","What do we deliberately exclude?"],"#496b83"),
("RISKS, GATES & DEPENDENCIES",["Which specialist review is required?","Which owner or prerequisite is missing?","What triggers pause or rollback?"],"#9a623f"),
("RECOMMENDATION & NEXT STEPS",["GO / ADAPT / HOLD / STOP—and why?","Named decision owner and next step?","What evidence is still not proven?"],"#745d7b")]
ew=1130; eg=55
for i,(title,items,c) in enumerate(evidence):
    svg.append(panel(160+i*(ew+eg),3040,ew,650,title,items,c,23))
# footer
svg += ['<rect x="160" y="3730" width="5880" height="84" rx="24" fill="#173d38"/>',
        '<text x="210" y="3782" font-size="24" fill="white" font-weight="700">INTERNAL PLANNING AID · No legal, privacy, security, labour, technical, or production approval is implied.</text>',
        '<text x="5970" y="3782" text-anchor="end" font-size="22" fill="#cbded6">Version 1.0 · 2026-09-28</text>', '</svg>']
svg_text=''.join(svg)
(OUT/'AI-Business-Strategy-Transformation-Whiteboard.svg').write_text(svg_text,encoding='utf-8')

# Rich phase details for the HTML inspector.
details={}
for i,p in enumerate(P):
    t=T[i]
    details[p[0]]={"code":p[0],"title":p[1],"track":"Capability & advisory learning","focus":p[2],"output":p[3],"completion":p[4],"paired":t[0]+" · "+t[1],"relationship":ENABLE[i],"transformation":t[2],"gate":GATES}
    details[t[0]]={"code":t[0],"title":t[1],"track":"Enterprise AI transformation","focus":t[2],"output":"Aligned capability: "+p[0]+" · "+p[1],"completion":"Advance only when the named next-step evidence and required owners/reviews are explicit.","paired":p[0]+" · "+p[1],"relationship":ENABLE[i],"transformation":t[2],"gate":GATES}

html=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AI Business Strategy & Transformation Whiteboard</title><style>
:root{{--ink:#173d38;--paper:#f3f0e7;--panel:#fffdf7;--line:#cbd5ce;--accent:#2f6f67;--shadow:0 12px 40px #132e2a22}}*{{box-sizing:border-box}}html,body{{height:100%;margin:0;overflow:hidden;background:var(--paper);color:#19312e;font-family:Arial,Helvetica,sans-serif}}.app{{display:grid;grid-template-rows:64px 1fr;height:100%}}header{{z-index:5;display:flex;align-items:center;gap:10px;padding:10px 14px;background:#173d38;color:#fff;box-shadow:var(--shadow)}}header strong{{font-size:16px;margin-right:auto;letter-spacing:.2px}}button,select{{height:42px;border:1px solid #7d958d;background:#fff;color:#173d38;border-radius:9px;padding:0 13px;font:700 14px Arial;cursor:pointer}}button:hover,button:focus-visible,select:focus-visible{{outline:3px solid #e0ad4f;outline-offset:2px}}.stage{{position:relative;overflow:hidden;touch-action:none;cursor:grab}}.stage.dragging{{cursor:grabbing}}#board{{position:absolute;transform-origin:0 0;will-change:transform;user-select:none}}#board svg{{display:block;width:6200px;height:3900px}}.hint{{position:absolute;left:18px;bottom:18px;background:#173d38eb;color:white;padding:10px 14px;border-radius:10px;font-size:13px;pointer-events:none}}.zoomread{{min-width:58px;text-align:center;color:#d8e8e1;font-weight:700}}dialog{{border:0;border-radius:18px;padding:0;width:min(620px,calc(100vw - 32px));max-height:calc(100vh - 90px);box-shadow:0 30px 100px #0b252080;background:#fffdf7;color:#19312e}}dialog::backdrop{{background:#122a2666}}.dhead{{padding:22px 24px 18px;background:#173d38;color:#fff;display:flex;gap:16px;align-items:start}}.badge{{font:900 17px Arial;border:1px solid #9fc2b5;border-radius:999px;padding:7px 10px}}.dhead h2{{margin:1px 0 3px;font-size:26px}}.dhead p{{margin:0;color:#d7e7df}}.close{{margin-left:auto;min-width:44px;border-color:#8eaaa0;font-size:20px}}.dbody{{padding:20px 24px 26px;overflow:auto;max-height:calc(100vh - 210px)}}details{{border-top:1px solid #d6ddd8;padding:13px 0}}summary{{cursor:pointer;font-weight:800;color:#315f57}}details p{{line-height:1.5;margin:10px 0}}.warning{{background:#f3ead7;border:1px solid #c49a54;border-radius:10px;padding:12px 14px;line-height:1.4}}.small{{font-size:12px;color:#526762}}@media(max-width:800px){{header strong{{display:none}}header{{overflow-x:auto}}.hint{{font-size:11px}}}}@media(prefers-reduced-motion:reduce){{*{{scroll-behavior:auto!important}}}}@media print{{header,.hint,dialog{{display:none!important}}body{{overflow:visible}}.stage{{overflow:visible}}#board{{position:static!important;transform:none!important}}#board svg{{width:100%;height:auto}}}}
</style></head><body><main class="app"><header><strong>AI BUSINESS STRATEGY · TRANSFORMATION WHITEBOARD</strong><button id="fit" title="Fit whole board (0)">Fit board</button><button id="zin" aria-label="Zoom in">＋</button><button id="zout" aria-label="Zoom out">−</button><span class="zoomread" id="zoom">100%</span><select id="jump" aria-label="Jump to phase"><option value="">Jump to phase…</option>{''.join(f'<option value="{k}">{k} · {escape(v["title"])}</option>' for k,v in details.items())}</select><button id="help">Help</button></header><section class="stage" id="stage" aria-label="Pan and zoom whiteboard"><div id="board">{svg_text}</div><div class="hint">Drag to pan · wheel/pinch or +/− to zoom · click a phase for detail · 0 resets</div></section></main>
<dialog id="inspector"><div class="dhead"><span class="badge" id="dcode">P0</span><div><h2 id="dtitle">Phase</h2><p id="dtrack"></p></div><button class="close" id="close" aria-label="Close details">×</button></div><div class="dbody"><details open><summary>Focus</summary><p id="dfocus"></p></details><details open><summary>Output / aligned capability</summary><p id="doutput"></p></details><details open><summary>Completion test</summary><p id="dcompletion"></p></details><details open><summary>Paired track & enabling link</summary><p><strong id="dpaired"></strong></p><p id="drelationship"></p><p id="dtransformation"></p></details><details><summary>Decision gate</summary><p id="dgate"></p></details><p class="warning">Reviews required; no approval assumed. This board is an internal planning aid, not evidence of production readiness.</p></div></dialog>
<dialog id="helpbox"><div class="dhead"><div><h2>Navigate the canvas</h2><p>Offline controls—no account or network required.</p></div><button class="close" id="helpclose">×</button></div><div class="dbody"><p><b>Pan:</b> drag empty canvas, use arrow keys, or touch-drag.</p><p><b>Zoom:</b> mouse wheel, trackpad, pinch, ＋/− buttons, or keyboard +/−.</p><p><b>Inspect:</b> click a P/T phase card, tab to a card and press Enter, or use the phase selector.</p><p><b>Reset:</b> Fit board or press 0. Press Escape to close a panel.</p><p class="small">All content is embedded in this file. No analytics, trackers, CDNs, accounts, or network calls.</p></div></dialog>
<script>const DATA={json.dumps(details,ensure_ascii=False)};const stage=document.querySelector('#stage'),board=document.querySelector('#board'),zoomEl=document.querySelector('#zoom');let s=1,x=0,y=0,drag=false,lastX=0,lastY=0;const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));function draw(){{board.style.transform=`translate(${{x}}px,${{y}}px) scale(${{s}})`;zoomEl.textContent=Math.round(s*100)+'%'}}function fit(){{const r=stage.getBoundingClientRect();s=Math.min(r.width/6200,r.height/3900)*.96;x=(r.width-6200*s)/2;y=(r.height-3900*s)/2;draw()}}function zoomAt(f,cx,cy){{const old=s;s=clamp(s*f,.08,2.5);x=cx-(cx-x)*(s/old);y=cy-(cy-y)*(s/old);draw()}}stage.addEventListener('wheel',e=>{{e.preventDefault();const r=stage.getBoundingClientRect();zoomAt(e.deltaY<0?1.12:.89,e.clientX-r.left,e.clientY-r.top)}},{{passive:false}});stage.addEventListener('pointerdown',e=>{{if(e.target.closest('.phase-card'))return;drag=true;lastX=e.clientX;lastY=e.clientY;stage.setPointerCapture(e.pointerId);stage.classList.add('dragging')}});stage.addEventListener('pointermove',e=>{{if(!drag)return;x+=e.clientX-lastX;y+=e.clientY-lastY;lastX=e.clientX;lastY=e.clientY;draw()}});stage.addEventListener('pointerup',()=>{{drag=false;stage.classList.remove('dragging')}});function showPhase(code){{const d=DATA[code];if(!d)return;for(const [k,v] of Object.entries(d)){{const el=document.querySelector('#d'+k);if(el)el.textContent=v}}document.querySelector('#inspector').showModal()}}document.querySelectorAll('.phase-card').forEach(el=>{{el.addEventListener('click',()=>showPhase(el.dataset.phase));el.addEventListener('keydown',e=>{{if(e.key==='Enter'||e.key===' '){{e.preventDefault();showPhase(el.dataset.phase)}}}})}});document.querySelector('#close').onclick=()=>document.querySelector('#inspector').close();document.querySelector('#fit').onclick=fit;document.querySelector('#zin').onclick=()=>zoomAt(1.2,stage.clientWidth/2,stage.clientHeight/2);document.querySelector('#zout').onclick=()=>zoomAt(.82,stage.clientWidth/2,stage.clientHeight/2);document.querySelector('#jump').onchange=e=>{{if(!e.target.value)return;const el=document.querySelector(`[data-phase="${{e.target.value}}"]`);const box=el.getBBox();s=.55;x=stage.clientWidth/2-(box.x+box.width/2)*s;y=stage.clientHeight/2-(box.y+box.height/2)*s;draw();showPhase(e.target.value);e.target.value=''}};document.querySelector('#help').onclick=()=>document.querySelector('#helpbox').showModal();document.querySelector('#helpclose').onclick=()=>document.querySelector('#helpbox').close();window.addEventListener('keydown',e=>{{if(document.querySelector('dialog[open]'))return;if(e.key==='0')fit();else if(e.key==='+'||e.key==='=')zoomAt(1.2,stage.clientWidth/2,stage.clientHeight/2);else if(e.key==='-')zoomAt(.82,stage.clientWidth/2,stage.clientHeight/2);else if(e.key==='ArrowLeft'){{x+=80;draw()}}else if(e.key==='ArrowRight'){{x-=80;draw()}}else if(e.key==='ArrowUp'){{y+=80;draw()}}else if(e.key==='ArrowDown'){{y-=80;draw()}}}});window.addEventListener('resize',fit);fit();window.__WHITEBOARD_READY__=true;</script></body></html>'''
(OUT/'AI-Business-Strategy-Transformation-Whiteboard.html').write_text(html,encoding='utf-8')

readme='''AI Business Strategy & Transformation Whiteboard
================================================

FILES
- AI-Business-Strategy-Transformation-Whiteboard.html — interactive offline whiteboard.
- AI-Business-Strategy-Transformation-Whiteboard.svg — 6200 × 3900 scalable master canvas.
- AI-Business-Strategy-Transformation-Whiteboard.pdf — printable one-page overview (when present).

OPEN AND USE
1. Extract the ZIP before use.
2. Open the HTML file in a current desktop browser. No server, account, or network connection is needed.
3. Drag the canvas to pan; use wheel/pinch or +/− to zoom; click a P/T phase card to open its detail panel. Fit board (or keyboard 0) resets the view. Arrow keys pan.
4. Open the SVG directly or import it into a whiteboard/presentation tool. Because it is vector-based, text and shapes remain sharp while zooming.
5. Print the PDF in landscape orientation using “fit to printable area”. The PDF is a big-picture overview; use HTML/SVG for drill-down.

READING ORDER
North Star → transformation question → paired P/T phase tracks → cross-cutting rails → evidence zone. Apply GO / ADAPT / HOLD / STOP at every phase. The management panel lists evidence limits, decision owners, and open decisions.

IMPORTANT BOUNDARY
This is an internal planning aid. It does not claim legal, privacy, security, labour, technical, production, or scale approval. Reviews are required and no approval is assumed. No company facts, customer data, or quantitative outcome claims are included.

PORTABILITY & PRIVACY
All HTML styles, scripts, and content are embedded. There are no external CDNs, analytics, trackers, network calls, or third-party accounts.
'''
(OUT/'README.txt').write_text(readme,encoding='utf-8')

# Optional PDF generation via CairoSVG, if present.
pdf_status='not-created'
try:
    import cairosvg
    cairosvg.svg2pdf(bytestring=svg_text.encode('utf-8'),write_to=str(OUT/'AI-Business-Strategy-Transformation-Whiteboard.pdf'),output_width=1684,output_height=1059)
    pdf_status='created-with-cairosvg'
except Exception as e:
    (OUT/'PDF-LIMITATION.txt').write_text('PDF generation was unavailable: '+str(e)+'\nThe SVG master is print-ready at 6200 × 3900.\n',encoding='utf-8')
    pdf_status='unavailable:'+type(e).__name__

# Manifest and deterministic clean ZIP.
manifest=[]
for f in sorted(OUT.iterdir()):
    if f.name!='MANIFEST.txt':
        manifest.append(f"{hashlib.sha256(f.read_bytes()).hexdigest()}  {f.name}")
(OUT/'MANIFEST.txt').write_text('\n'.join(manifest)+'\n',encoding='utf-8')
zip_path=ROOT/'AI-Business-Strategy-Transformation-Whiteboard-Package.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for f in sorted(OUT.iterdir()): z.write(f,arcname=f'ai-business-strategy-whiteboard/{f.name}')
print(json.dumps({'out':str(OUT),'zip':str(zip_path),'pdf_status':pdf_status,'files':[f.name for f in sorted(OUT.iterdir())]},indent=2))
