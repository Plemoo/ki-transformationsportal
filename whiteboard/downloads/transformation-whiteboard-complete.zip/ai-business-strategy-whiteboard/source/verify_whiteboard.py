#!/usr/bin/env python3
from pathlib import Path
from lxml import etree, html as lhtml
from pypdf import PdfReader
from playwright.sync_api import sync_playwright
import cairosvg, zipfile, tempfile, hashlib, json, re, shutil, sys

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'ai-business-strategy-whiteboard'
HTML=OUT/'AI-Business-Strategy-Transformation-Whiteboard.html'
SVG=OUT/'AI-Business-Strategy-Transformation-Whiteboard.svg'
PDF=OUT/'AI-Business-Strategy-Transformation-Whiteboard.pdf'
ZIP=ROOT/'AI-Business-Strategy-Transformation-Whiteboard-Package.zip'
PNG=ROOT/'whiteboard-render-check.png'
checks=[]
def check(name, ok, detail=''):
    checks.append((name,bool(ok),detail))
    if not ok: raise AssertionError(name+': '+detail)

# Structural and content validation.
svg_root=etree.parse(str(SVG)).getroot()
check('SVG XML parses',svg_root.tag.endswith('svg'))
check('SVG dimensions',svg_root.get('width')=='6200' and svg_root.get('height')=='3900',f"{svg_root.get('width')}x{svg_root.get('height')}")
cairosvg.svg2png(url=str(SVG),write_to=str(PNG),output_width=1860,output_height=1170)
check('SVG renders to PNG',PNG.stat().st_size>100000,f'{PNG.stat().st_size} bytes')
raw=HTML.read_text(encoding='utf-8')
doc=lhtml.fromstring(raw)
check('HTML has embedded SVG',len(doc.xpath('//*[local-name()="svg"]'))==1)
check('HTML has 16 phase cards',len(doc.xpath('//*[contains(concat(" ", normalize-space(@class), " "), " phase-card ")]'))==16)
check('No external runtime references',not re.search(r'<(?:script|link|img)[^>]+(?:src|href)=["\'](?:https?:)?//',raw,re.I))
check('No network APIs',not re.search(r'\b(fetch\s*\(|XMLHttpRequest|WebSocket\s*\()',raw))
required=[
'NORTH STAR','PLANNING TARGET','TRANSFORMATION QUESTION','CAPABILITY &amp; ADVISORY LEARNING','ENTERPRISE AI TRANSFORMATION',
'BUSINESS VALUE','PEOPLE &amp; CHANGE','GOVERNANCE &amp; SPECIALIST GATES','EVIDENCE &amp; DECISION DISCIPLINE',
'GO','ADAPT','HOLD','STOP','MANAGEMENT CONTROL PANEL','CURRENT EVIDENCE BASELINE','RECOMMENDED NEXT DEPENDENCY',
'DECISION OWNERS','OPEN DECISIONS','FACTS &amp; SOURCES','ASSUMPTIONS &amp; DATA GAPS','OPTIONS &amp; TRADE-OFFS',
'RISKS, GATES &amp; DEPENDENCIES','RECOMMENDATION &amp; NEXT STEPS','REVIEWS REQUIRED; NO APPROVAL ASSUMED'
]
missing=[v for v in required if v not in raw]
check('All required board sections present',not missing,', '.join(missing))
for i in range(8):
    check(f'Phase P{i}/T{i} present',f'"P{i}"' in raw and f'"T{i}"' in raw)
check('No unsupported numeric performance claims',not re.search(r'\b(?:ROI|revenue|cost|productivity|accuracy)\b[^<\n]{0,40}\b\d+(?:\.\d+)?\s*%',raw,re.I))
check('PDF has one page',len(PdfReader(str(PDF)).pages)==1)
check('PDF nontrivial',PDF.stat().st_size>30000,f'{PDF.stat().st_size} bytes')

# Real browser interaction smoke test.
def browser_smoke(path, screenshot=None):
    errs=[]; external=[]
    with sync_playwright() as p:
        b=p.chromium.launch(headless=True)
        page=b.new_page(viewport={'width':1600,'height':1000},device_scale_factor=1)
        page.on('pageerror',lambda e: errs.append(str(e)))
        page.on('console',lambda m: errs.append('console:'+m.text) if m.type=='error' else None)
        page.on('request',lambda r: external.append(r.url) if not r.url.startswith('file:') and not r.url.startswith('data:') else None)
        page.goto(path.resolve().as_uri(),wait_until='load')
        ready=page.evaluate('window.__WHITEBOARD_READY__===true')
        initial=page.locator('#board').evaluate('(e)=>e.style.transform')
        page.click('#zin'); zoomed=page.locator('#board').evaluate('(e)=>e.style.transform')
        page.locator('[data-phase="P4"]').click(force=True)
        p4=page.locator('#inspector').get_attribute('open') is not None and page.locator('#dtitle').inner_text()=='Design reversible pilot'
        page.click('#close')
        page.select_option('#jump','T6')
        t6=page.locator('#inspector').get_attribute('open') is not None and page.locator('#dtitle').inner_text()=='Value decision'
        page.click('#close')
        page.click('#help'); helpok=page.locator('#helpbox').get_attribute('open') is not None
        page.click('#helpclose')
        page.keyboard.press('0'); reset=page.locator('#board').evaluate('(e)=>e.style.transform')
        if screenshot: page.screenshot(path=str(screenshot),full_page=False)
        b.close()
    return {'ready':ready,'initial':initial,'zoomed':zoomed,'zoom_changed':initial!=zoomed,'p4':p4,'t6':t6,'help':helpok,'reset':reset,'errors':errs,'external':external}

smoke=browser_smoke(HTML,ROOT/'whiteboard-browser-smoke.png')
check('HTML loads with ready flag',smoke['ready'])
check('Zoom control changes transform',smoke['zoom_changed'])
check('P4 click opens correct expandable detail',smoke['p4'])
check('Phase selector opens T6 detail',smoke['t6'])
check('Help control opens and closes',smoke['help'])
check('Browser has no page/console errors',not smoke['errors'],str(smoke['errors']))
check('Browser performs no external requests',not smoke['external'],str(smoke['external']))

# Fresh-unpack and repeat a real browser smoke test.
with tempfile.TemporaryDirectory(prefix='whiteboard-unpack-') as td:
    with zipfile.ZipFile(ZIP) as z: z.extractall(td)
    base=Path(td)/'ai-business-strategy-whiteboard'
    expected=['AI-Business-Strategy-Transformation-Whiteboard.html','AI-Business-Strategy-Transformation-Whiteboard.svg','AI-Business-Strategy-Transformation-Whiteboard.pdf','README.txt','MANIFEST.txt']
    check('Fresh ZIP contains all expected files',all((base/f).exists() for f in expected))
    fresh=browser_smoke(base/expected[0])
    check('Fresh-unpack HTML ready',fresh['ready'])
    check('Fresh-unpack controls work',fresh['zoom_changed'] and fresh['p4'] and fresh['t6'] and fresh['help'])
    check('Fresh-unpack browser clean',not fresh['errors'] and not fresh['external'],str(fresh['errors']+fresh['external']))

print(json.dumps({'checks':len(checks),'passed':sum(ok for _,ok,_ in checks),'smoke':smoke,'sizes':{p.name:p.stat().st_size for p in [HTML,SVG,PDF,ZIP,PNG,ROOT/'whiteboard-browser-smoke.png']}},ensure_ascii=False,indent=2))
