# Wissensportal MVP – lokale P0-Nachbesserung

Dependency-freies Python-3.11-MVP für ausschließlich synthetische D0/D1-Inhalte. Der Server bindet ausschließlich an 127.0.0.1; es gibt keine externe Kommunikation, Persistenz, Telemetrie, Produktiv-IAM oder Veröffentlichung.

## Nachgewiesener Funktionsumfang

- Vollständiger gemeinsamer Metadatenkopf und Freigabevalidierung; D2/D3 werden abgewiesen.
- I/R/N sowie unbekannte und rein technische Rollen sind Default-Deny vor Listen, Suche, Facetten, Detail, Vergleich und Download; `portal_admin` ohne fachliche Rolle erhält kein Inhaltsrecht.
- Sieben verlinkte Hauptbereiche, Breadcrumbs, getrenntes Archiv und versionsgenaue Detail-/Downloadlinks.
- Kombinierbare Pflichtfilter: Typ, Modul/Phase, Status, Klasse, Evidenz, Gate, Owner, Gültigkeit, nächste Prüfung, Datenklasse, Downloadfähigkeit und Tags; sichtbarer Zustand und Reset.
- HTTP/UI-Vergleich von ein bis drei gleichartigen berechtigten Inhalten sowie serverseitige Negativregeln.
- Versionsgenauer Einzel-Download mit Metadaten, Quelle, Lizenz und Nutzungshinweis: `/download/<id>` verlangt die exakte Query `version=<ressourcen-version>` und antwortet bei fehlender, falscher oder unbekannter Version neutral mit 404; kein Bulk-Export.
- Synthetischer in-memory Lifecycle: Entwurf, Review, Gate, interne Freigabe, neue Version/Changelog, Gate-Entzug, Archivierung, Löschprüfung und datensparsamer Tombstone.
- Accessibility-/Responsive-Smokes: semantische Landmarken/Labels, sichtbarer Fokus, Textstatus, responsive Navigation/Tabelle, lokale Hilfe, leere Zustände und neutrale 404.

## Lokaler Start

    cd <entpacktes-verzeichnis>
    python3 -m knowledge_portal.server

Im selben System öffnen: http://127.0.0.1:8000 . Mit Ctrl-C beenden.

## Tests

    python3 -m unittest discover -s tests -v
    python3 -m py_compile knowledge_portal/app.py knowledge_portal/server.py
    python3 -m compileall -q knowledge_portal tests

## Reset und Rückbau

Der Store ist nur in-memory: Server stoppen und erneut starten erzeugt den unveränderlichen D0/D1-Seed. Zum vollständigen lokalen Rückbau den Server stoppen und das entpackte Verzeichnis löschen. Es werden keine Dienste, Datenbanken, Konten, Netzwerkregeln oder externen Ressourcen angelegt.

## Grenzen

Diese Rollen-Demo ist kein IAM. Reale Daten, D2/D3, produktive Persistenz, Backup/Restore, revisionssicheres Audit, echte Lösch-/Aufbewahrungsentscheidung, Fach-Gates (Recht, Datenschutz, InfoSec, Arbeitsrecht/Mitbestimmung, Lizenz), Betrieb und jede Außenpublikation bleiben ausdrücklich außerhalb des MVPs.