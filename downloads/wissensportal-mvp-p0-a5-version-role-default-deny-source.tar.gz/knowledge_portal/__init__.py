"""Local-only Wissensportal MVP package."""
