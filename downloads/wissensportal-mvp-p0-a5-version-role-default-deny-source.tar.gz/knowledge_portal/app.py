"""Dependency-free domain model for the loopback-only Wissensportal MVP."""
from __future__ import annotations

from copy import deepcopy
from datetime import date
from typing import Iterable

ROLES = {"reader", "restricted_reader", "editor", "gate_owner", "contributor", "peer_reviewer", "content_owner", "publication_owner", "records_reviewer"}
REQUIRED_FIELDS = {
    "id", "type", "title", "summary", "purpose", "owner", "owner_confirmed", "version", "status",
    "publication_class", "evidence", "source", "gate_status", "gate_details", "valid_until", "validity_scope",
    "dependencies", "next_review", "data_class", "license_status", "allowed_use", "download_allowed", "tags",
    "section", "module_phase", "changed_at", "change_reason", "change_owner", "predecessor", "successor",
    "retention_status", "retention_owner", "non_goals", "changelog",
}
RELEASABLE = {"intern freigegeben", "eingeschränkt"}
BLOCKING_GATES = {"offen", "in prüfung", "nicht bestanden", "entzogen", "abgelaufen"}
FILTER_FIELDS = ("type", "module_phase", "status", "publication_class", "evidence", "gate_status", "owner", "validity", "next_review", "data_class", "download_allowed", "tag")


class ValidationError(ValueError):
    """A record cannot be used or released in this local synthetic MVP."""


class Catalog:
    """In-memory catalog. Authorization is evaluated before every result set."""
    def __init__(self, records: Iterable[dict]):
        self._records = [self._validate(dict(record)) for record in records]
        self._tombstones: dict[str, dict] = {}

    @classmethod
    def seeded(cls) -> "Catalog":
        return cls(_seed_records())

    @staticmethod
    def _validate(record: dict) -> dict:
        missing = REQUIRED_FIELDS - record.keys()
        if missing:
            raise ValidationError("missing required metadata: " + ", ".join(sorted(missing)))
        if record["data_class"] not in {"D0", "D1"}:
            raise ValidationError("only D0/D1 synthetic data is allowed")
        if record["publication_class"] not in {"I", "R", "N"}:
            raise ValidationError("invalid publication class")
        if not isinstance(record["gate_details"], list) or not record["gate_details"]:
            raise ValidationError("at least one gate detail is required")
        if record["status"] in RELEASABLE:
            required_release = (record["owner_confirmed"], record["publication_class"] in {"I", "R"},
                                record["gate_status"] == "bestanden", bool(record["valid_until"]),
                                bool(record["dependencies"]), bool(record["next_review"]))
            if not all(required_release):
                raise ValidationError("release validation failed")
        return record

    @staticmethod
    def _role(role: str) -> str:
        return role if role in ROLES else ""

    @staticmethod
    def _validity(record: dict) -> str:
        if record["valid_until"] < date.today().isoformat():
            return "abgelaufen"
        if record["next_review"] <= date.today().isoformat():
            return "prüfung fällig"
        return "gültig"

    @classmethod
    def _active(cls, record: dict) -> bool:
        return (record["status"] not in {"archiviert", "ersetzt", "löschprüfung"}
                and record["gate_status"] == "bestanden" and cls._validity(record) == "gültig")

    def allowed(self, record: dict, role: str, include_inactive: bool = False) -> bool:
        role = self._role(role)
        if not role:
            return False
        if record["publication_class"] == "N":
            return False
        if record["publication_class"] == "R" and role not in {"restricted_reader", "editor", "gate_owner"}:
            return False
        return include_inactive or self._active(record)

    @staticmethod
    def _matches(record: dict, filters: dict) -> bool:
        for key, value in filters.items():
            if not value:
                continue
            expected = str(value).lower()
            actual = record.get(key, "")
            if key == "validity":
                actual = Catalog._validity(record)
            elif key == "tag":
                if expected not in {str(tag).lower() for tag in record["tags"]}:
                    return False
                continue
            elif key == "download_allowed":
                actual = str(bool(actual)).lower()
            if str(actual).lower() != expected:
                return False
        return True

    def list_visible(self, role: str, filters: dict | None = None, include_inactive: bool = False) -> list[dict]:
        filters = filters or {}
        visible = [record for record in self._records if self.allowed(record, role, include_inactive)]
        return deepcopy([record for record in visible if self._matches(record, filters)])

    def search(self, query: str, role: str, filters: dict | None = None) -> list[dict]:
        query = query.lower().strip()
        records = self.list_visible(role, filters)
        if not query:
            return records
        return [record for record in records if query in " ".join(map(str, (record["id"], record["title"], record["summary"], record["purpose"], *record["tags"]))).lower()]

    def facets(self, role: str, filters: dict | None = None) -> dict[str, dict[str, int]]:
        fields = ("type", "module_phase", "status", "publication_class", "evidence", "gate_status", "owner", "validity", "next_review", "data_class", "download_allowed", "tag")
        result = {field: {} for field in fields}
        for record in self.list_visible(role, filters):
            for field in fields:
                values = record["tags"] if field == "tag" else [self._validity(record) if field == "validity" else record[field]]
                for value in values:
                    result[field][str(value)] = result[field].get(str(value), 0) + 1
        return result

    def get(self, record_id: str, role: str, include_inactive: bool = False) -> dict | None:
        record = next((item for item in self._records if item["id"] == record_id), None)
        return deepcopy(record) if record and self.allowed(record, role, include_inactive) else None

    def compare(self, record_ids: list[str], role: str) -> list[dict] | None:
        if not 1 <= len(record_ids) <= 3 or len(set(record_ids)) != len(record_ids):
            return None
        records = [self.get(record_id, role) for record_id in record_ids]
        if any(record is None for record in records) or len({record["type"] for record in records}) != 1:
            return None
        return records

    def download(self, record_id: str, role: str) -> str | None:
        record = self.get(record_id, role)
        if record is None or not record["download_allowed"] or record["publication_class"] != "I":
            return None
        return (f"# {record['title']}\n\nID: {record['id']}\nVersion: {record['version']}\nStatus: {record['status']}\n"
                f"Owner: {record['owner']}\nEvidenz: {record['evidence']}\nGates: {record['gate_details']}\n"
                f"Gültigkeit: {record['valid_until']} ({record['validity_scope']})\nQuelle: {record['source']}\n"
                f"Lizenz: {record['license_status']}\nNutzung: {record['allowed_use']}\nAbruf: lokale Demo-Ausgabe\n\n{record['summary']}\n")

    def bulk_download(self, record_ids: list[str], role: str) -> None:
        return None

    def _raw(self, record_id: str) -> dict:
        record = next((item for item in self._records if item["id"] == record_id), None)
        if record is None:
            raise ValidationError("unknown record")
        return record

    def create_draft(self, record_id: str, content_type: str, title: str, actor: str) -> dict:
        if actor != "contributor" or any(item["id"] == record_id for item in self._records):
            raise ValidationError("draft creation denied")
        record = _record(record_id, "Zielbild & Roadmaps", content_type, title, status="Entwurf", publication_class="N", gate_status="offen", download_allowed=False)
        self._records.append(self._validate(record))
        return deepcopy(record)

    def submit_review(self, record_id: str, actor: str) -> None:
        if actor != "peer_reviewer": raise ValidationError("review denied")
        self._raw(record_id)["status"] = "im Review"

    def record_gate(self, record_id: str, gate: str, status: str, actor: str) -> None:
        if actor != "gate_owner" or status not in {"bestanden", "offen", "entzogen", "abgelaufen", "nicht bestanden"}: raise ValidationError("gate update denied")
        record = self._raw(record_id)
        record["gate_status"] = status
        record["gate_details"] = [{"name": gate, "status": status, "owner": "Gate Owner (Rolle)", "condition": "synthetische Demo"}]

    def approve_internal(self, record_id: str, content_owner: str, publication_owner: str) -> None:
        if (content_owner, publication_owner) != ("content_owner", "publication_owner"): raise ValidationError("approval denied")
        record = self._raw(record_id)
        record.update(status="intern freigegeben", publication_class="I", owner_confirmed=True, gate_status="bestanden")
        self._validate(record)

    def new_version(self, record_id: str, reason: str, actor: str) -> dict:
        if actor != "editor": raise ValidationError("version denied")
        old = self._raw(record_id)
        major, minor, patch = map(int, old["version"].split("."))
        version = f"{major}.{minor + 1}.0"
        new_id = f"{record_id}@{version}"
        new = deepcopy(old)
        new.update(id=new_id, version=version, predecessor=record_id, successor="", change_reason=reason,
                   changelog=old["changelog"] + [f"{version}: {reason}"], changed_at=date.today().isoformat())
        old["successor"] = new_id
        self._records.append(self._validate(new))
        return deepcopy(new)

    def withdraw_gate(self, record_id: str, gate: str, actor: str) -> None:
        self.record_gate(record_id, gate, "entzogen", actor)

    def archive(self, record_id: str, successor: str, reason: str, actor: str) -> None:
        if actor != "editor": raise ValidationError("archive denied")
        record = self._raw(record_id); record.update(status="archiviert", successor=successor, change_reason=reason)

    def request_deletion(self, record_id: str, actor: str) -> None:
        if actor != "records_reviewer": raise ValidationError("deletion review denied")
        self._raw(record_id)["status"] = "löschprüfung"

    def confirm_deletion(self, record_id: str, actor: str) -> None:
        if actor != "records_reviewer" or self._raw(record_id)["status"] != "löschprüfung": raise ValidationError("deletion denied")
        self._records = [record for record in self._records if record["id"] != record_id]
        self._tombstones[record_id] = {"id": record_id, "deletion_reason_category": "synthetische demo-löschung"}

    def tombstone(self, record_id: str, actor: str) -> dict | None:
        return deepcopy(self._tombstones.get(record_id)) if actor in {"editor", "records_reviewer"} else None


def _record(record_id: str, section: str, content_type: str, title: str, **overrides: object) -> dict:
    data = {"id": record_id, "section": section, "type": content_type, "title": title,
        "summary": "Synthetisches, abstrahiertes Beispiel für das lokale MVP.", "purpose": "Interne Entscheidungsorientierung ohne Produktivfreigabe.",
        "owner": "Content Owner (Rolle)", "owner_confirmed": True, "version": "1.0.0", "status": "intern freigegeben", "publication_class": "I", "evidence": "H", "source": "Synthetischer Seed / t_2e5af365", "gate_status": "bestanden", "gate_details": [{"name": "recht", "status": "bestanden", "owner": "Gate Owner (Rolle)", "condition": "nur lokale D0/D1-Demo"}], "valid_until": "2099-12-31", "validity_scope": "lokales MVP", "dependencies": ["GATE-LOCAL-01"], "next_review": "2099-01-01", "data_class": "D0", "license_status": "interne Demo-Nutzung", "allowed_use": "nur lokale interne Demonstration", "download_allowed": True, "tags": ["strategie", "synthetisch"], "module_phase": "E", "changed_at": "2026-09-27", "change_reason": "Erstfassung", "change_owner": "Content Owner (Rolle)", "predecessor": "", "successor": "", "retention_status": "synthetischer Seed – keine Aufbewahrung", "retention_owner": "Records/Privacy Reviewer (Rolle)", "non_goals": "Keine Produktiv-, Rechts- oder Außenfreigabe.", "changelog": ["1.0.0: Erstfassung"]}
    data.update(overrides); return data


def _seed_records() -> list[dict]:
    return [_record("I-ROADMAP-01", "Zielbild & Roadmaps", "roadmap", "Zielbild und Roadmap"), _record("I-OFFER-01", "Angebotsbaukasten", "angebot", "Einstiegspaket E", module_phase="P1"), _record("I-METHOD-01", "Methoden & Vorlagen", "methode", "Readiness-Analyse"), _record("I-USECASE-01", "Muster-Use-Cases", "use_case", "Assistierte Servicewissensrecherche"), _record("I-GATE-01", "Governance & Gates", "governance", "Lokales Gate-Modell"), _record("I-DECISION-01", "Entscheidungen & Änderungen", "entscheidung", "Go/Hold-Entscheidung"), _record("I-ARCHIVE-01", "Archiv", "roadmap", "Ersetzte Roadmap", status="archiviert"), _record("R-METHOD-01", "Methoden & Vorlagen", "methode", "Eingeschränkte Methodenkarte", publication_class="R", data_class="D1", download_allowed=False), _record("N-DRAFT-01", "Governance & Gates", "governance", "Nicht publizierbarer Entwurf", publication_class="N", status="Entwurf", gate_status="offen", download_allowed=False), _record("I-EXPIRED-01", "Entscheidungen & Änderungen", "entscheidung", "Abgelaufenes Gate", status="ersetzt", gate_status="abgelaufen", valid_until="2000-01-01")]
