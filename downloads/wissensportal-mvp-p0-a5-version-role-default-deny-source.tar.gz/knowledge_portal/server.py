"""Loopback-only HTTP interface for the local Wissensportal MVP."""
from __future__ import annotations

from html import escape
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, quote, urlparse

from .app import Catalog, FILTER_FIELDS

SECTIONS = ["Zielbild & Roadmaps", "Angebotsbaukasten", "Methoden & Vorlagen", "Muster-Use-Cases", "Governance & Gates", "Entscheidungen & Änderungen", "Archiv"]
COMPARE_FIELDS = ("purpose", "non_goals", "version", "status", "evidence", "gate_details", "valid_until", "owner", "dependencies", "change_reason")


def _query_value(query: dict[str, list[str]], name: str, default: str = "") -> str:
    return query.get(name, [default])[0]


def _url(path: str, role: str, **params: str) -> str:
    tail = "&".join(f"{quote(k)}={quote(v)}" for k, v in {"role": role, **params}.items() if v)
    return f"{path}?{tail}" if tail else path


def _layout(title: str, body: str, role: str) -> bytes:
    nav = " ".join(f"<a href='{_url('/section/' + quote(section, safe=''), role)}'>{escape(section)}</a>" for section in SECTIONS)
    page = f"""<!doctype html><html lang='de'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width, initial-scale=1'><title>{escape(title)}</title>
<style>body{{font-family:sans-serif;max-width:960px;margin:auto;padding:1rem;color:#111;background:#fff}}a{{color:#0645ad}}a:focus-visible,button:focus-visible,input:focus-visible{{outline:3px solid #b00020;outline-offset:2px}}.notice{{background:#e6f0ff;padding:.7rem;border-left:4px solid #0645ad}}.status{{font-weight:bold}}.table-wrap{{overflow-x:auto}}@media(max-width:600px){{nav a{{display:block;padding:.35rem 0}}body{{padding:.5rem}}table{{font-size:.9rem}}}}</style>
</head><body><header><h1>Wissensportal MVP</h1><p class='notice'>Rollen-Demo: {escape(role)} — keine Authentisierung oder Produktivfreigabe. Status wird als Text angezeigt, nicht nur über Farbe.</p><nav aria-label='Hauptnavigation'>{nav} <a href='{_url('/help', role)}'>Hilfe</a></nav></header><main>{body}</main></body></html>"""
    return page.encode()


def _breadcrumb(section: str, title: str, role: str) -> str:
    return f"<nav aria-label='Breadcrumb'><a href='{_url('/', role)}'>Start</a> / <a href='{_url('/section/' + quote(section, safe=''), role)}'>{escape(section)}</a> / {escape(title)}</nav>"


class PortalHandler(BaseHTTPRequestHandler):
    catalog = Catalog.seeded()
    def log_message(self, format: str, *args: object) -> None: return
    def _send(self, status: int, body: bytes, content_type: str = "text/html; charset=utf-8", headers: dict[str, str] | None = None) -> None:
        self.send_response(status); self.send_header("Content-Type", content_type); self.send_header("Content-Length", str(len(body)))
        for name, value in (headers or {}).items(): self.send_header(name, value)
        self.end_headers(); self.wfile.write(body)
    def _not_found(self) -> None: self._send(404, b"Not found\n", "text/plain; charset=utf-8")

    def _records_page(self, role: str, filters: dict, section: str | None = None) -> None:
        if section:
            filters = {**filters, "section": section}
            records = self.catalog.list_visible(role, filters, include_inactive=section == "Archiv")
            heading = "Archivbestand" if section == "Archiv" else section
        else:
            records = self.catalog.search("", role, filters); heading = "Treffer"
        rows = "".join(f"<li><a href='{_url('/detail/' + quote(record['id'], safe=''), role, version=record['version'])}'>{escape(record['title'])}</a> <span class='status'>({escape(record['id'])}, {escape(record['version'])}, {escape(record['publication_class'])})</span></li>" for record in records) or "<li>Keine zulässigen Treffer.</li>"
        self._send(200, _layout(heading, f"<h2>{escape(heading)}</h2><ul>{rows}</ul>", role))

    def do_GET(self) -> None:
        parsed = urlparse(self.path); query = parse_qs(parsed.query); role = _query_value(query, "role", "reader")
        filters = {field: _query_value(query, field) for field in FILTER_FIELDS}
        if parsed.path in {"/", "/search"}:
            records = self.catalog.search(_query_value(query, "q"), role, filters)
            rows = "".join(f"<li><a href='{_url('/detail/' + quote(record['id'], safe=''), role, version=record['version'])}'>{escape(record['title'])}</a> ({escape(record['id'])}, {escape(record['version'])}, {escape(record['publication_class'])})</li>" for record in records) or "<li>Keine zulässigen Treffer.</li>"
            inputs = "".join(f"<label>{escape(field)} <input name='{escape(field)}' value='{escape(value)}'></label> " for field, value in filters.items())
            active = ", ".join(f"{escape(key)}={escape(value)}" for key, value in filters.items() if value) or "keine"
            facets = self.catalog.facets(role, filters)
            body = f"<h2>Suche</h2><form method='get'><label>Suche <input name='q' value='{escape(_query_value(query, 'q'))}'></label><input type='hidden' name='role' value='{escape(role)}'>{inputs}<button>Suchen</button> <a href='{_url('/search', role)}'>Filter zurücksetzen</a></form><p>Aktive Filter: {active}</p><h2>Treffer</h2><ul>{rows}</ul><h2>Facetten</h2><pre>{escape(str(facets))}</pre>"
            self._send(200, _layout("Suche", body, role)); return
        if parsed.path.startswith("/section/"):
            section = parsed.path.rsplit("/", 1)[-1]
            if section not in SECTIONS: self._not_found(); return
            self._records_page(role, filters, section); return
        if parsed.path.startswith("/detail/"):
            record = self.catalog.get(parsed.path.rsplit("/", 1)[-1], role)
            if record is None: self._not_found(); return
            metadata = "".join(f"<dt>{escape(key)}</dt><dd>{escape(str(value))}</dd>" for key, value in record.items() if key != "summary")
            version_link = _url('/detail/' + quote(record['id'], safe=''), role, version=record['version'])
            download = f"<p><a href='{_url('/download/' + quote(record['id'], safe=''), role, version=record['version'])}'>Versionsgenauer Download</a></p>" if record["download_allowed"] else ""
            body = f"{_breadcrumb(record['section'], record['title'], role)}<h2>{escape(record['title'])}</h2><p>{escape(record['summary'])}</p><p><a href='{version_link}'>Version {escape(record['version'])}</a></p><dl>{metadata}</dl>{download}"
            self._send(200, _layout(record["title"], body, role)); return
        if parsed.path == "/compare":
            ids = query.get("id", [])
            records = self.catalog.compare(ids, role)
            if records is None: self._not_found(); return
            header = "".join(f"<th>{escape(record['title'])} ({escape(record['version'])})</th>" for record in records)
            table = "".join(f"<tr><th>{escape(field if field != 'change_reason' else 'Änderungen')}</th>{''.join(f'<td>{escape(str(record[field]))}</td>' for record in records)}</tr>" for field in COMPARE_FIELDS)
            body = f"<h2>Vergleich</h2><p>Qualitäts-/Abbruchregeln: Vergleich ist Entscheidungshilfe; maximal drei gleichartige berechtigte Inhalte.</p><div class='table-wrap'><table><thead><tr><th>Feld</th>{header}</tr></thead><tbody>{table}</tbody></table></div>"
            self._send(200, _layout("Vergleich", body, role)); return
        if parsed.path == "/help":
            body = "<h2>Hilfe</h2><p>Navigation, kombinierbare Filter und Filter zurücksetzen sind ohne JavaScript bedienbar. Vergleiche erlauben höchstens drei gleichartige, berechtigte Inhalte. Archiv ist vom aktuellen Bestand getrennt.</p><p>Bei fehlendem Recht, abgelaufenem oder entzogenem Gate erscheint eine neutrale Fehlermeldung ohne Inhaltsdetails. Downloads sind Einzel- und Versionsdownloads, kein Bulk-Export.</p>"
            self._send(200, _layout("Hilfe", body, role)); return
        if parsed.path.startswith("/download/"):
            record_id = parsed.path.rsplit("/", 1)[-1]
            if record_id == "bulk": self._not_found(); return
            requested_version = _query_value(query, "version")
            record = self.catalog.get(record_id, role)
            if record is None or not requested_version or record["version"] != requested_version:
                self._not_found(); return
            text = self.catalog.download(record_id, role)
            if text is None: self._not_found(); return
            headers = {"Content-Disposition": f'attachment; filename="{record_id}-{record["version"]}.md"'}
            self._send(200, text.encode(), "text/markdown; charset=utf-8", headers); return
        self._not_found()


def make_server(host: str = "127.0.0.1", port: int = 8000) -> ThreadingHTTPServer:
    if host != "127.0.0.1": raise ValueError("MVP server may bind only to 127.0.0.1")
    return ThreadingHTTPServer((host, port), PortalHandler)

def main() -> None:
    server = make_server(); print("Wissensportal MVP listening at http://127.0.0.1:8000")
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()
if __name__ == "__main__": main()
