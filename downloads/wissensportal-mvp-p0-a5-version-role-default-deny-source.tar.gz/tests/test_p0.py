import unittest
from datetime import date, timedelta

from knowledge_portal.app import Catalog, ValidationError


class P0DomainTests(unittest.TestCase):
    def setUp(self):
        self.catalog = Catalog.seeded()

    def test_release_requires_all_specification_metadata_and_passing_gates(self):
        record = self.catalog.get("I-ROADMAP-01", "reader")
        for field in ("purpose", "owner_confirmed", "source", "validity_scope", "gate_details",
                      "changed_at", "change_reason", "change_owner", "predecessor", "successor",
                      "retention_status", "retention_owner", "non_goals"):
            self.assertIn(field, record)
        invalid = dict(record)
        invalid["owner_confirmed"] = False
        with self.assertRaises(ValidationError):
            Catalog([invalid])
        invalid = dict(record)
        invalid["gate_details"] = []
        with self.assertRaises(ValidationError):
            Catalog([invalid])

    def test_all_required_filters_combine_and_facets_are_authorized_and_filtered(self):
        filters = {"type": "roadmap", "module_phase": "E", "status": "intern freigegeben",
                   "publication_class": "I", "evidence": "H", "gate_status": "bestanden",
                   "owner": "Content Owner (Rolle)", "validity": "gültig", "next_review": "2099-01-01",
                   "data_class": "D0", "download_allowed": "true", "tag": "strategie"}
        results = self.catalog.search("", "reader", filters)
        self.assertEqual([item["id"] for item in results], ["I-ROADMAP-01"])
        facets = self.catalog.facets("reader", filters)
        self.assertEqual(facets["publication_class"], {"I": 1})
        self.assertNotIn("R", facets["publication_class"])

    def test_lifecycle_creates_version_with_changelog_and_handles_revocation_archive_and_tombstone(self):
        draft = self.catalog.create_draft("LC-01", "roadmap", "Entwurf", "contributor")
        self.catalog.submit_review("LC-01", "peer_reviewer")
        self.catalog.record_gate("LC-01", "recht", "bestanden", "gate_owner")
        self.catalog.approve_internal("LC-01", "content_owner", "publication_owner")
        released = self.catalog.get("LC-01", "reader")
        self.assertEqual(released["status"], "intern freigegeben")
        successor = self.catalog.new_version("LC-01", "MINOR: Ergänzte Erläuterung", "editor")
        self.assertEqual(successor["version"], "1.1.0")
        self.assertTrue(any(entry.startswith("1.1.0:") for entry in successor["changelog"]))
        self.catalog.withdraw_gate(successor["id"], "recht", "gate_owner")
        self.assertIsNone(self.catalog.get(successor["id"], "reader"))
        self.catalog.archive("LC-01", successor["id"], "ersetzt", "editor")
        archived = self.catalog.get("LC-01", "reader", include_inactive=True)
        self.assertEqual(archived["status"], "archiviert")
        self.catalog.request_deletion("LC-01", "records_reviewer")
        self.assertEqual(self.catalog.get("LC-01", "reader", include_inactive=True)["status"], "löschprüfung")
        self.catalog.confirm_deletion("LC-01", "records_reviewer")
        tombstone = self.catalog.tombstone("LC-01", "editor")
        self.assertEqual(tombstone, {"id": "LC-01", "deletion_reason_category": "synthetische demo-löschung"})

    def test_download_rejects_n_restricted_expired_revoked_and_bulk(self):
        self.assertIsNone(self.catalog.download("N-DRAFT-01", "gate_owner"))
        self.assertIsNone(self.catalog.download("R-METHOD-01", "restricted_reader"))
        self.assertIsNone(self.catalog.download("I-EXPIRED-01", "reader"))
        self.catalog.withdraw_gate("I-ROADMAP-01", "recht", "gate_owner")
        self.assertIsNone(self.catalog.download("I-ROADMAP-01", "reader"))
        self.assertIsNone(self.catalog.bulk_download(["I-OFFER-01"], "reader"))


if __name__ == "__main__":
    unittest.main()
