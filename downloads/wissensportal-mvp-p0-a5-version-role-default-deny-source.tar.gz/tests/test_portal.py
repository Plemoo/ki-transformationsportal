import unittest

from knowledge_portal.app import Catalog, ValidationError


class CatalogPolicyTests(unittest.TestCase):
    def setUp(self):
        self.catalog = Catalog.seeded()

    def test_reader_can_only_see_internal_visible_records(self):
        ids = {record["id"] for record in self.catalog.list_visible("reader")}
        self.assertIn("I-ROADMAP-01", ids)
        self.assertNotIn("R-METHOD-01", ids)
        self.assertNotIn("N-DRAFT-01", ids)

    def test_restricted_reader_can_see_restricted_record(self):
        self.assertIsNotNone(self.catalog.get("R-METHOD-01", "restricted_reader"))

    def test_unknown_or_technical_only_role_has_no_content_rights(self):
        for role in ("unknown", "portal_admin"):
            self.assertEqual(self.catalog.list_visible(role), [])
            self.assertIsNone(self.catalog.get("I-ROADMAP-01", role))
            self.assertIsNone(self.catalog.download("I-ROADMAP-01", role))

    def test_gate_owner_keeps_existing_restricted_scope(self):
        self.assertIsNotNone(self.catalog.get("R-METHOD-01", "gate_owner"))

    def test_non_publishable_record_is_never_visible(self):
        self.assertIsNone(self.catalog.get("N-DRAFT-01", "gate_owner", include_inactive=True))

    def test_search_and_facets_are_authorized_before_counting(self):
        results = self.catalog.search("R-METHOD-01", "reader")
        self.assertEqual(results, [])
        self.assertNotIn("R", self.catalog.facets("reader")["publication_class"])

    def test_expired_gate_is_excluded_from_regular_use(self):
        self.assertIsNone(self.catalog.get("I-EXPIRED-01", "reader"))

    def test_d2_and_missing_metadata_are_rejected(self):
        valid = self.catalog.get("I-ROADMAP-01", "reader")
        valid["data_class"] = "D2"
        with self.assertRaises(ValidationError):
            Catalog([valid])
        valid = self.catalog.get("I-ROADMAP-01", "reader")
        del valid["owner"]
        with self.assertRaises(ValidationError):
            Catalog([valid])

    def test_compare_rejects_mixed_types_and_more_than_three_records(self):
        self.assertIsNone(self.catalog.compare(["I-ROADMAP-01", "I-OFFER-01"], "reader"))
        self.assertIsNone(self.catalog.compare(["I-ROADMAP-01"] * 4, "reader"))

    def test_download_is_exact_version_and_refuses_restricted_record(self):
        download = self.catalog.download("I-ROADMAP-01", "reader")
        self.assertIn("ID: I-ROADMAP-01", download)
        self.assertIn("Version: 1.0.0", download)
        self.assertIsNone(self.catalog.download("R-METHOD-01", "restricted_reader"))

    def test_seed_contains_all_seven_sections_and_archived_is_hidden(self):
        sections = {record["section"] for record in self.catalog.list_visible("reader")}
        self.assertEqual(sections, {
            "Zielbild & Roadmaps", "Angebotsbaukasten", "Methoden & Vorlagen",
            "Muster-Use-Cases", "Governance & Gates", "Entscheidungen & Änderungen",
        })
        self.assertNotIn("I-ARCHIVE-01", {record["id"] for record in self.catalog.list_visible("reader")})


if __name__ == "__main__":
    unittest.main()
