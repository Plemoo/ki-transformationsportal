import threading
import unittest
from urllib.error import HTTPError
from urllib.request import urlopen

from knowledge_portal.server import make_server


class HttpP0Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = make_server("127.0.0.1", 0)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f"http://127.0.0.1:{cls.server.server_port}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown(); cls.server.server_close(); cls.thread.join(timeout=2)

    def fetch(self, path):
        with urlopen(self.base + path) as response:
            return response, response.read().decode()

    def test_sections_breadcrumb_archive_and_version_links_are_navigable(self):
        _, home = self.fetch("/?role=reader")
        self.assertIn("href='/section/Zielbild%20%26%20Roadmaps?role=reader'", home)
        _, detail = self.fetch("/detail/I-ROADMAP-01?role=reader")
        self.assertIn("aria-label='Breadcrumb'", detail)
        self.assertIn("/detail/I-ROADMAP-01?role=reader&version=1.0.0", detail)
        _, archive = self.fetch("/section/Archiv?role=reader")
        self.assertIn("Archivbestand", archive)

    def test_filter_state_reset_and_a11y_responsive_help_are_rendered(self):
        _, body = self.fetch("/search?role=reader&type=roadmap&module_phase=E")
        self.assertIn("Aktive Filter", body)
        self.assertIn("Filter zurücksetzen", body)
        self.assertIn("<main", body)
        self.assertIn(":focus-visible", body)
        self.assertIn("@media", body)
        _, help_page = self.fetch("/help?role=reader")
        self.assertIn("Hilfe", help_page)
        self.assertIn("neutrale Fehlermeldung", help_page)

    def test_compare_ui_and_download_headers_and_negative_bulk_are_real_http(self):
        response, body = self.fetch("/compare?role=reader&id=I-ROADMAP-01")
        self.assertIn("Vergleich", body)
        self.assertIn("Qualitäts-/Abbruchregeln", body)
        response, download = self.fetch("/download/I-ROADMAP-01?role=reader&version=1.0.0")
        self.assertEqual(response.headers["Content-Disposition"], 'attachment; filename="I-ROADMAP-01-1.0.0.md"')
        self.assertIn("Quelle:", download)
        for path in ("/download/N-DRAFT-01?role=gate_owner", "/download/R-METHOD-01?role=restricted_reader", "/download/bulk?role=reader"):
            with self.assertRaises(HTTPError) as captured:
                urlopen(self.base + path)
            self.assertEqual(captured.exception.code, 404)

    def test_download_requires_the_exact_requested_version_without_metadata_leak(self):
        response, _ = self.fetch("/download/I-ROADMAP-01?role=reader&version=1.0.0")
        self.assertEqual(response.status, 200)
        for path in (
            "/download/I-ROADMAP-01?role=reader&version=9.9.9",
            "/download/I-ROADMAP-01?role=reader&version=0.0.0",
            "/download/I-ROADMAP-01?role=reader",
        ):
            with self.assertRaises(HTTPError) as captured:
                urlopen(self.base + path)
            self.assertEqual(captured.exception.code, 404)
            self.assertEqual(captured.exception.read().decode(), "Not found\n")

    def test_download_rejects_expired_and_revoked_gates_without_metadata_leak(self):
        for path in ("/download/I-EXPIRED-01?role=reader&version=1.0.0",):
            with self.assertRaises(HTTPError) as captured:
                urlopen(self.base + path)
            self.assertEqual(captured.exception.code, 404)
            self.assertEqual(captured.exception.read().decode(), "Not found\n")
        self.server.RequestHandlerClass.catalog.withdraw_gate("I-ROADMAP-01", "recht", "gate_owner")
        try:
            with self.assertRaises(HTTPError) as captured:
                urlopen(self.base + "/download/I-ROADMAP-01?role=reader&version=1.0.0")
            self.assertEqual(captured.exception.code, 404)
            self.assertEqual(captured.exception.read().decode(), "Not found\n")
        finally:
            self.server.RequestHandlerClass.catalog = self.server.RequestHandlerClass.catalog.seeded()


if __name__ == "__main__":
    unittest.main()
