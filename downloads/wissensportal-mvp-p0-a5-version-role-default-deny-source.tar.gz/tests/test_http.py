import threading
import unittest
from urllib.error import HTTPError
from urllib.request import urlopen

from knowledge_portal.server import make_server


class HttpPortalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = make_server("127.0.0.1", 0)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f"http://127.0.0.1:{cls.server.server_port}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=2)

    def test_home_lists_navigation_and_reader_search_has_no_restricted_leak(self):
        with urlopen(self.base + "/search?q=strategie&role=reader") as response:
            body = response.read().decode()
        self.assertIn("Zielbild &amp; Roadmaps", body)
        self.assertIn("Rollen-Demo", body)
        self.assertNotIn("R-METHOD-01", body)

    def test_direct_unallowed_detail_and_download_return_neutral_404(self):
        for path in ("/detail/R-METHOD-01?role=reader", "/download/R-METHOD-01?role=reader"):
            with self.assertRaises(HTTPError) as captured:
                urlopen(self.base + path)
            self.assertEqual(captured.exception.code, 404)
            self.assertNotIn("R-METHOD-01", captured.exception.read().decode())


if __name__ == "__main__":
    unittest.main()
